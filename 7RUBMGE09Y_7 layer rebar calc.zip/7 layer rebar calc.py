n = int(input())
L = []
for i in range(n):
    m = int(input())
    L.append(m)

length = len(L)

all_possible_pairs = []

if length >= 6:
    count1 = 0
    count = 0
    for i in range(length):
        for j in range(i+1, length):
            for k in range(j+1, length):
                for o in range(k+1, length):
                    for p in range(o+1, length):
                        for q in range(p+1, length):
                            total = L[i] + L[j] + L[k] + L[o] + L[p] + L[q]
                            count1 += 1
                            if total <= 12000:
                                each_pair = str(L[i]) + " + " + str(L[j]) + " + " + str(L[k]) + " + " + str(L[o]) + " + " + str(L[p]) + " + " + str(L[q]) +" = "+ str(total)
                                all_possible_pairs.append((total, each_pair))
                                count += 1
    print(count1)
    print(count)
    
    
if length >= 5:
    count1 = 0
    count = 0
    for i in range(length):
        for j in range(i+1, length):
            for k in range(j+1, length):
                for o in range(k+1, length):
                    for p in range(o+1, length):
                        total = L[i] + L[j] + L[k] + L[o] + L[p]
                        count1 += 1
                        if total <= 12000:
                            each_pair = str(L[i]) + " + " + str(L[j]) + " + " + str(L[k]) + " + " + str(L[o]) + " + " + str(L[p]) +" = "+ str(total)
                            all_possible_pairs.append((total, each_pair))
                            count += 1
    print(count1)
    print(count)


if length >= 4:
    count1 = 0
    count = 0
    for i in range(length):
        for j in range(i+1, length):
            for k in range(j+1, length):
                for o in range(k+1, length):
                    total = L[i] + L[j] + L[k] + L[o]
                    count1 += 1
                    if total <= 12000:
                        each_pair = str(L[i]) + " + " + str(L[j]) + " + " + str(L[k]) + " + " + str(L[o])+" = "+ str(total)
                        all_possible_pairs.append((total, each_pair))
                        count += 1
    print(count1)
    print(count)


if length >= 3:
    count1 = 0
    count = 0
    for i in range(length):
        for j in range(i+1, length):
            for k in range(j+1, length):
                total = L[i] + L[j] + L[k]
                count1 += 1
                if total <= 12000:
                    each_pair = str(L[i]) + " + " + str(L[j]) + " + " + str(L[k]) +" = "+ str(total)
                    all_possible_pairs.append((total, each_pair))
                    count += 1
    print(count1)
    print(count)
    
if length >= 2:
    count1 = 0
    count = 0
    for i in range(length):
        for j in range(i, length):
            total = L[i] + L[j]
            count1 += 1
            if total <= 12000:
                each_pair = str(L[i]) + " + " + str(L[j]) +" = "+ str(total)
                all_possible_pairs.append((total, each_pair))
                count += 1
    print(count1)
    print(count)

     
if length == 1:
    print(L[0])
    
    
    
all_possible_pairs.sort(reverse = True)
expressions = []
for i, j in all_possible_pairs:
    expressions.append(j)

numbers = L

# Given numbers list (can have duplicates)



# Expressions we want to check and remove numbers from the list


# Step 1: Create a copy of the numbers list to work on
remaining_numbers = numbers[:]  # This is our working list
valid_expressions = []          # This will hold successful expressions
count = 1
# Step 2: Go through each expression
for expression in expressions:
    
    
    # Now split at "=" to ignore the total sum part
    number_part = expression.split("=")[0]  # gives "6100 + 5070 "
    
    # Split the numbers by "+" and clean spaces
    number_strings = number_part.strip().split("+")
    
    # Convert each number string to an integer
    required_numbers = []
    for item in number_strings:
        required_numbers.append(int(item.strip()))
    
    # Now check if all required numbers are available in the list
    temp_list = remaining_numbers[:]  # Make a copy to test removals
    all_found = True                  # Flag to track if everything is available
    
    for value in required_numbers:
        if value in temp_list:
            temp_list.remove(value)  # Remove just one copy
        else:
            all_found = False        # One of the numbers is missing
            break
    
    # If all numbers were found, accept this expression
    if all_found:
        new_expression = str(count) +") "+ expression 
        count += 1
        valid_expressions.append(new_expression)   # Save the expression
        remaining_numbers = temp_list          # Commit the removal

# Step 3: Show the results
print("Highly Efficient Combination of Rebars for Cutting to Minimize Waste As Far As Possible")
for exp in valid_expressions:
    print(exp)

print("Remaining Bars :")
print(remaining_numbers)